print('Comp intel placeholder')
