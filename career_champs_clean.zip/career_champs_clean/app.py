print('Career Champs Streamlit app entrypoint')
