print('Remotive fetch placeholder')
