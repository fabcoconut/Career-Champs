print('Scoring placeholder')
